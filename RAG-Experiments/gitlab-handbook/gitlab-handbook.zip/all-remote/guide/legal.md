---
title: "Remote Guide for Legal Teams"
description: Remote Guide for Legal Teams
twitter_image: "/images/opengraph/all-remote.jpg"
twitter_image_alt: "GitLab remote team graphic"
twitter_site: "@gitlab"
twitter_creator: "@gitlab"
---

## Introduction

We are building a remote guide for legal teams, which will be added to this page soon. *Pending legal review, of course.*

----

Return to the main [all-remote page]({{< ref "../_index.md" >}}).
